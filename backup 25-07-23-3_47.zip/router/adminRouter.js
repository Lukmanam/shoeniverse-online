const express = require('express');
const admin_route = express();
const adminController = require('../controller/adminController');
// const auth = require('../middleware/adminAuth');

admin_route.set('view engine', 'ejs');
admin_route.set('views', './views/admin');

admin_route.get('/', adminController.loadHome)

module.exports = admin_route