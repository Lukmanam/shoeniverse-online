const sessionSecret="mysitesessionsecret";
module.exports ={
    sessionSecret
}